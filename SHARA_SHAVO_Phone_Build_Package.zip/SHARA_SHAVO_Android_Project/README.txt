SHARA SHAVO — Android app project

WHAT THIS IS
This is an Android Studio project for an early SHARA SHAVO app. It opens a bundled video-posting interface in a native Android app shell. It supports choosing a video, posting it in the local feed, local likes and comments.

IMPORTANT LIMITATIONS
- This is source code, not an already compiled/installable APK.
- It does not yet have online accounts, shared posts, cloud video storage, moderation, or a server.
- Likes/comments are local demo interactions and posts are not shared with other phones.
- To build an APK, open this folder in Android Studio on a computer with Android SDK installed, allow Gradle sync, then choose Build > Build APK(s).
- Do not collect passwords or personal information until proper secure authentication and privacy rules are implemented.

PACKAGE: com.sharashavo.app
APP NAME: SHARA SHAVO
MIN ANDROID: Android 6.0 (API 23)


PHONE-ONLY BUILD ROUTE
A GitHub Actions workflow is included at .github/workflows/build-apk.yml.
From a phone:
1. Sign in to GitHub and create a new repository.
2. Upload the contents of this project to the repository (including the hidden .github folder; if the mobile upload flow makes this difficult, use GitHub's web upload/create-file features).
3. Open the repository's Actions tab and run "Build SHARA SHAVO APK" if it did not start automatically.
4. When the workflow succeeds, open the run, find Artifacts, and download SHARA-SHAVO-debug-APK.
5. Extract the downloaded artifact ZIP and tap app-debug.apk to install it. Android may ask you to allow installation from that source.

This route needs a GitHub account and internet access. The APK will be a debug build for testing, not a Play Store release. The app remains a local demo without online sharing.
